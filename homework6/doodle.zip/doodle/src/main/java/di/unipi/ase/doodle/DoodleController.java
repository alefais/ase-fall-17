package di.unipi.ase.doodle;

import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

@RestController
public class DoodleController {
    private int id = 0;
    private HashMap<Integer, Doodle> doodles = new HashMap<>();

    /************* /doodles/ **********************/

    @RequestMapping(value="/doodles", method = RequestMethod.PUT)
    public long createDoodle(@RequestBody Doodle d){
        doodles.put(id, new Doodle(d));
        id++;
        return id - 1;
    }

    @RequestMapping(value="/doodles", method = RequestMethod.GET)
    public HashMap<Integer, Doodle> getDoodles(){
        return doodles;
    }

    /************* /doodles/{id}/ **********************/

    @RequestMapping(value="/doodles/{id}", method = RequestMethod.DELETE)
    public void deleteDoodle(@PathVariable("id") int id){
        doodles.remove(id);
    }

    @RequestMapping(value="/doodles/{id}", method = RequestMethod.GET)
    public Doodle getDoodle(@PathVariable("id") int id){
        return doodles.get(id);
    }

    /************* /doodles/{id}/vote **********************/

    @RequestMapping(value="/doodles/{id}/vote", method = RequestMethod.PUT)
    public String vote(
            @PathVariable("id") int id,
            @RequestBody Vote v){
        System.out.println(v.getName() + " " + v.getOption());
        return doodles.get(id).addVote(v);
    }

    /************* /doodles/{id}/vote **********************/

    @RequestMapping(value="/doodles/{id}/vote/{name}", method = RequestMethod.GET)
    public String getVote(
            @PathVariable("id") int id,
            @PathVariable("name") String name){
        return doodles.get(id).findPreviousVote(name);
    }


    @RequestMapping(value="/doodles/{id}/vote/{name}", method = RequestMethod.POST)
    public String updateVote(
            @PathVariable("id") int id,
            @RequestBody Vote v){
        return doodles.get(id).addVote(v);
    }

    @RequestMapping(value="/doodles/{id}/vote/{name}", method = RequestMethod.DELETE)
    public void deleteVote(
            @PathVariable("id") int id,
            @PathVariable("name") String name){
        doodles.get(id).removeVote(name);
    }

}
